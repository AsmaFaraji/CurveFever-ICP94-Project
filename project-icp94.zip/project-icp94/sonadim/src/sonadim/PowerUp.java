package sonadim;
import java.awt.*;
import javax.swing.*;
import java.awt.image.BufferedImage;

public class PowerUp {
	int x;
	int y;
	int identifier;
	boolean catched;
	public PowerUp(int identifier) {
		x = utils.rand.nextInt(400) + 100;
		y = utils.rand.nextInt(600) + 100;
		this.identifier = identifier;
		catched = false;
		
		
		
	}
	
	void speedPowerUp( Snake[] snake, int playernumber )
	{
		double rsnake = 3.5;
		double rpower = 15;
		double centersDistance = 0;
			for(int i = 0;i < playernumber;i++){
				centersDistance = Math.sqrt(Math.pow(x + 15  - snake[i].x + 3.5, 2) + Math.pow(y + 15 - snake[i].y + 3.5, 2));
					if((centersDistance <= rsnake + rpower) && identifier == 0){
						snake[i].v.len = 2.5;
						catched = true;
					}	
					else 
						if((centersDistance <= rsnake + rpower) && identifier == 1)
							for(int j = 0;j<playernumber;j++)
								if(j != i ){
									snake[j].v.len = 2.5;
									catched = true;
								}	
		}	
	}

}
