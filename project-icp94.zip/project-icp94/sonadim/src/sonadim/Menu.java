package sonadim;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

class Menu extends JFrame implements ActionListener, MouseListener,KeyListener {
	JLabel crv, fvr;
	JLabel[] p;
	JLabel bot;
	JLabel plyr;
	JLabel left;
	JLabel right;

	JTextField[] lp;
	JTextField[] rp;

	JButton play;
	JButton[] b;
	Snake[] player;
	Color[] color;
	
	int[] rightkey;
	int[] leftkey;
	int playernumber;
	int l;

	Menu() {
		setTitle("Curve Fever");
		setBounds(20, 20, 700, 700);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.BLACK);
		setVisible(true);
		setLayout(null);
		
		rightkey = new int[6];
		leftkey = new int[6];

		player = new Snake[6];
		color = new Color[6];
		crv = new JLabel("CURVE");
		crv.setFont(new Font("Serif", Font.BOLD, 50));
		crv.setForeground(Color.RED);
		crv.setBounds(700 / 2 - crv.getPreferredSize().width / 2, 2, crv.getPreferredSize().width,
				crv.getPreferredSize().height);
		add(crv);

		fvr = new JLabel("FEVER");
		fvr.setFont(new Font("Serif", Font.BOLD, 50));
		fvr.setForeground(Color.RED);
		fvr.setBounds(700 / 2 - fvr.getPreferredSize().width / 2, (int) crv.getPreferredSize().getHeight() + 5,
				fvr.getPreferredSize().width, fvr.getPreferredSize().height);
		add(fvr);

		JLabel plyr = new JLabel("PLAYER");
		plyr.setFont(new Font("Leberation Serif", Font.HANGING_BASELINE, 20));
		plyr.setForeground(Color.GREEN);
		plyr.setBounds(50, 200, plyr.getPreferredSize().width, plyr.getPreferredSize().height);
		add(plyr);

		JLabel left = new JLabel("LEFT");
		left.setFont(new Font("Leberation Serif", Font.HANGING_BASELINE, 20));
		left.setForeground(Color.GREEN);
		left.setBounds(300, 200, plyr.getPreferredSize().width, plyr.getPreferredSize().height);
		add(left);

		JLabel right = new JLabel("RIGHT");
		right.setFont(new Font("Leberation Serif", Font.HANGING_BASELINE, 20));
		right.setForeground(Color.GREEN);
		right.setBounds(450, 200, plyr.getPreferredSize().width, plyr.getPreferredSize().height);
		add(right);

		JLabel bot = new JLabel("BOT");
		bot.setFont(new Font("Leberation Serif", Font.HANGING_BASELINE, 20));
		bot.setForeground(Color.ORANGE);
		bot.setBounds(600, 200, plyr.getPreferredSize().width, plyr.getPreferredSize().height);
		add(bot);
		p = new JLabel[6];
		for (int i = 0; i < 6; i++) {
			p[i] = new JLabel((i + 1) + ".player");
			p[i].setFont(new Font("Garamond", Font.HANGING_BASELINE, 20));
			p[i].setForeground(new Color(100, 100, 100));
			p[i].setBounds(50, 200 + 50 * (i + 1), p[i].getPreferredSize().width, p[i].getPreferredSize().height);
			add(p[i]);
		}
		p[0].setForeground(Color.YELLOW);
		color[0] = Color.YELLOW;
		p[1].setForeground(Color.RED);
		color[1] = Color.RED;
		p[2].setForeground(Color.GREEN);
		color[2] = Color.GREEN;
		p[3].setForeground(Color.BLUE);
		color[3] = Color.BLUE;
		p[4].setForeground(Color.WHITE);
		color[4] = Color.WHITE;
		p[5].setForeground(Color.MAGENTA);
		color[5] = Color.MAGENTA;
		lp = new JTextField[6];
		for (int i = 0; i < 6; i++) {
			lp[i] = new JTextField(1);
			lp[i].setBounds(300, 200 + 50 * (i + 1), plyr.getPreferredSize().width, plyr.getPreferredSize().height);
			lp[i].setFont(new Font("Garandom", Font.BOLD, 20));
			lp[i].setForeground(Color.MAGENTA);
			lp[i].setEnabled(false);
			lp[i].setBackground(Color.BLACK);
			lp[i].addKeyListener(this);
			lp[i].setActionCommand("lp" + i + 1);
			add(lp[i]);

		}
		rp = new JTextField[6];
		for (int i = 0; i < 6; i++) {
			rp[i] = new JTextField(1);
			rp[i].setBounds(450, 200 + 50 * (i + 1), plyr.getPreferredSize().width, plyr.getPreferredSize().height);
			rp[i].setFont(new Font("Garandom", Font.BOLD, 20));
			rp[i].setForeground(Color.MAGENTA);
			rp[i].setEnabled(false);
			rp[i].setBackground(Color.BLACK);
			rp[i].addKeyListener(this);
			add(rp[i]);

		}

		b = new JButton[6];
		for (int i = 0; i < 6; i++) {
			b[i] = new JButton("BOT");
			b[i].setBackground(Color.GREEN);
			b[i].setForeground(Color.YELLOW);
			b[i].setBounds(600, 200 + 50 * (i + 1), plyr.getPreferredSize().width, plyr.getPreferredSize().height);
			b[i].setFont(new Font("Garamond", Font.TRUETYPE_FONT, 20));
			add(b[i]);

		}
		play = new JButton("P L A Y");
		play.setFont(new Font("Georgia", Font.BOLD, 20));
		play.setForeground(Color.PINK);
		play.setBackground(Color.BLACK);
		play.setBounds(300 - 100 / 2, 600, 150, 50);
		add(play);

		for (int i = 0; i < 6; i++) {
			p[i].addMouseListener(this);
		}
		for (int i = 0; i < 6; i++) {
			b[i].setActionCommand(i +"");
			b[i].addActionListener(this);
		}
		play.setActionCommand("play");
		play.addActionListener(this);

		setVisible(true);
		repaint();

	}

	public void mouseClicked(MouseEvent event) {
		JLabel label = (JLabel) event.getSource();
		for (int i = 0; i < 6; i++) {
			if (p[i] == label) {
				p[i].setForeground(new Color(100,100,100));
				lp[i].setEnabled(true);
				rp[i].setEnabled(true);
				player[playernumber] = new Snake();
				player[playernumber].color = color[i];
				p[playernumber].removeMouseListener(this);
				b[playernumber].removeActionListener(this);
				player[playernumber].l = l + 1;
				l++;
				playernumber++;
			}
		}			
	}
	public void keyPressed(KeyEvent e) {
		JTextField text = (JTextField)(e.getSource());
		text.setText((e.getKeyCode() + ""));
		for(int i = 0;i<6;i++)
			if(text == lp[i])
				leftkey[i] = e.getKeyCode();
			else
				if(text ==  rp[i])
					rightkey[i] = e.getKeyCode();
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("play")) {
			getKey();
			dispose();
			create();
		} else {
			JButton button = (JButton) (e.getSource());
			button.setForeground(Color.blue);
			player[playernumber] = new Snake();
			player[playernumber].bot = true;
			player[playernumber].color = color[Integer.parseInt(e.getActionCommand())];
			p[Integer.parseInt(e.getActionCommand())].removeMouseListener(this);
			b[Integer.parseInt(e.getActionCommand())].removeActionListener(this);
			player[playernumber].l = l +1;
			l++;
			playernumber++;
		}
	}

	void getKey() {
		for (int i = 0; i < playernumber; i++) {
			if (!(player[i].bot)){
				for(int j = 0;j<6;j++)
					if(color[j] == player[i].color){
						player[i].left = leftkey[j];
						player[i].right = rightkey[j];
					}
			}

		}
	}

	void create() {
		getKey();
		dispose();
		loadGameScreen();
	}

	void loadGameScreen() {
		JFrame frame = new JFrame();
		frame.setSize(800,700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gameboard game = new gameboard(player, playernumber, frame);
		frame.add(game);
		frame.setVisible(true);
		
	}
	public void keyReleased(KeyEvent e) {}
	public void keyTyped(KeyEvent e) {}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}

	public static void main(String[] args) {
		Menu m = new Menu();
	}
}