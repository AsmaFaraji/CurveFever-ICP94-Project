import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.Timer;
import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Gameboard extends JComponent implements KeyListener, ActionListener {

	Snake[] player;
	JLabel[] pscore;
	JLabel[] score;
	PowerUp[] sposition;
	Snake S = new Snake();
	int playernumber;
	Graphics2D g2d;
	BufferedImage buffer;
	BufferedImage img;
	Timer timer;
	Timer time;
	// Graphics g;
	ActionListener power;
	boolean powerappear;
	boolean pause = true;
	boolean a = false;
	int x = 0;
	int y = 0;

	public Gameboard(Snake[] player, int playernumber) {

		this.setLocation(0, 0);
		this.setSize(800, 1000);
		this.setVisible(true);
		setFocusable(true);
		addKeyListener(this);
		this.player = player;
		this.playernumber = playernumber;
		pscore = new JLabel[playernumber];
		score = new JLabel[playernumber];
		S = player[0];
		buffer = new BufferedImage(800, 800, BufferedImage.TYPE_INT_RGB);
		g2d = (Graphics2D) buffer.getGraphics();

		RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHints(rh);

		scoreBoard();
		coloringBorder();
		drawFirstDirection();
		timer = new Timer(25, this);
		// Scanner scan = new Scanner(System.in);
		// int x = scan.nextInt();
		// if(x == 1)
		// timer.start();

		/*
		 * power = new ActionListener(){ public void actionPerformed(ActionEvent
		 * e){ // if(utils.rand.nextDouble()<0.03) appearPowerUp(); } };
		 */
		// time = new Timer(50, power);
		// time.start();
	}

	public void actionPerformed(ActionEvent e) {
		System.out.println("done");
		for (int i = 0; i < playernumber; i++) {
			if (!player[i].isBot())
				userMovement(player[i]);
			 else{
				 player[i].adjustVector();
				 player[i].directionDignosing();
				 // for(int j = 0;j<3;j++)
				 //System.out.println(player[i].path[j]);
				 userMovement(player[i]);
			 }
		}
		repaint();

	}

	public void paintComponent(Graphics g) {
		int tedad;
		int identifier;
		// int i = 2;
		// this.g = g;
		// super.paintComponent(g);
		// Snake S = getPlayer();
		// g2d.setColor(S.color);
		// g2d.fill(new Ellipse2D.Double(S.x, S.y, 4, 4));
		g.drawImage(buffer, 0, 0, null);

		/*if (!a) {
			if (utils.rand.nextDouble() < 0.03) {
				a = true;
				x = utils.rand.nextInt(500) + 100;
				y = utils.rand.nextInt(500) + 100;
				Timer t = new Timer(10, new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						a = false;
					}
				});
				t.setRepeats(false);
				t.setInitialDelay(10000);
				t.start();
				tedad = utils.rand.nextInt(5) + 1;
				sposition = new PowerUp[tedad];
				for (int i = 0; i < sposition.length; i++) {
					System.out.println("powerup");
					identifier = utils.rand.nextInt(1);
					sposition[i] = new PowerUp(identifier); //
					// sposition[i].speedPowerUp(player, playernumber);
				}
			}
		}

		if (a && !(PowerUp.catched)) {
			for (int i = 0; i < sposition.length; i++) {
				if (sposition[i].identifier == 1) {
					try {
						img = ImageIO.read(this.getClass().getResource("1.png"));
					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					try {
						img = ImageIO.read(this.getClass().getResource("2.png"));
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				g.drawImage(img, sposition[i].x, sposition[i].y, null);
				sposition[i].speedPowerUp(player, playernumber);
			}
		}*/

		/*
		 * Sys
		 * 
		 * 
		 * tem.out.println("powerup"); int tedad; int identifier;
		 * if(utils.rand.nextDouble() < 0.03){ tedad = utils.rand.nextInt(5) +
		 * 1; sposition = new PowerUp[tedad]; for(int i = 0;i<tedad;i++){
		 * System.out.println("powerup"); identifier = utils.rand.nextInt(2);
		 * sposition[i] = new PowerUp(identifier); try { img =
		 * ImageIO.read(this.getClass().getResource("p.png")); } catch
		 * (IOException e) { e.printStackTrace(); } g.drawImage(img,
		 * sposition[i].x, sposition[i].y, null); } }
		 */

	}

	protected void paintBorder(Graphics g) {
		g.setColor(Color.blue);
		g.drawRect(0, 0, 600, 800);
		g.drawRect(601, 0, 198, 800);
	}

	void coloringBorder()
	{
		for(int i = 0;i<600;i++){
			utils.colored[0][i] = 1;
			utils.colored[799][i] = 1;
		}
		for(int i = 0;i<800;i++){
			utils.colored[i][0] = 1;
			utils.colored[i][599] = 1;
		}	
	}

	void drawFirstDirection() {
		for (int i = 0; i < playernumber; i++) {
			for (int j = 0; j < 10; j++) {
				// System.out.println(buffer.getRGB(0, 0));// rgb
				Color c = new Color(buffer.getRGB(0, 0));
				//System.out.println(c.getBlue() + " " + c.getRed() + " " + c.getGreen());// ro
																						// bepors
				g2d.setColor(player[i].color);
				g2d.fill(new Ellipse2D.Double(player[i].x, player[i].y, 7, 7));
				player[i].lastx[j] = player[i].x;
				player[i].lasty[j] = player[i].y;
				player[i].x += player[i].v.getX();
				player[i].y += player[i].v.getY();
			}
			player[i].lastx[10] = player[i].x;
			player[i].lasty[10] = player[i].y;
			g2d.setColor(player[i].headcolor);
			g2d.fill(new Ellipse2D.Double(player[i].x, player[i].y, 7, 7));
			player[i].coloring(player[i].lastx, player[i].lasty);
			repaint();
		}
	}

	void userMovement(Snake S) {
		System.out.println(S.alive);
		if (S.alive) {
			/*
			 * if (S.x == S.firstx && S.y == S.firsty) { g2d.setColor(S.color);
			 * g2d.fill(new Ellipse2D.Double(S.x, S.y, 7, 7)); S.rotate(); S.x
			 * += S.v.getX(); S.y += S.v.getY(); S.lastx[11] = S.x; S.lasty[11]
			 * = S.y; S.coloring(S.lastx,S.lasty); g2d.setColor(S.headcolor);
			 * g2d.fill(new Ellipse2D.Double(S.x, S.y, 7, 7)); }
			 */
			// g2d.setColor(new Color(buffer.getRGB(0,0)));
			// g2d.fill(new Ellipse2D.Double(S.x, S.y, 7, 7));
			g2d.setColor(S.color);
			g2d.fill(new Ellipse2D.Double(S.x, S.y, 7, 7));
			// S.alive = S.isAlive( S.lastx, S.lasty, (int) S.x, (int) S.y);
			// S.coloring(S.lastx, S.lasty);
			// S.shift(S.lastx, S.lasty,S.x,S.y);
			S.rotate();
			S.x += S.v.getX();
			S.y += S.v.getY();
			g2d.setColor(S.headcolor);
			g2d.fill(new Ellipse2D.Double(S.x, S.y, 7, 7));
			S.alive = S.isAlive(S.lastx, S.lasty, (int) S.x, (int) S.y);
			S.shift(S.lastx, S.lasty, S.x, S.y);
			S.coloring(S.lastx, S.lasty);
			// S.shift(S.lastx, S.lasty,S.x,S.y);
			if (!S.alive && !S.lost) {
				S.lost = true;
				score();
			}
			// gameOver();

		}
	}

	void appearPowerUp() {
		System.out.println("powerup");
		int tedad;
		int identifier;
		if (utils.rand.nextDouble() < 0.03) {
			tedad = utils.rand.nextInt(5) + 1;
			sposition = new PowerUp[tedad];
			for (int i = 0; i < tedad; i++) {
				System.out.println("powerup");
				identifier = utils.rand.nextInt(2);
				sposition[i] = new PowerUp(identifier);
				try {
					img = ImageIO.read(this.getClass().getResource("p.png"));
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}
	}

	public void scoreBoard() {
		for (int i = 0; i < playernumber; i++) {
			pscore[i] = new JLabel("" + (i + 1) + '.' + "PLAYER");
			pscore[i].setFont(new Font("Garandom", Font.BOLD, 10));
			pscore[i].setForeground(player[i].color);
			pscore[i].setBounds(610, 20 + (i * 30), pscore[i].getPreferredSize().width,
					pscore[i].getPreferredSize().height);
			add(pscore[i]);
			score[i] = new JLabel("" + player[i].score);
			score[i].setFont(new Font("Garandom", Font.BOLD, 10));
			score[i].setForeground(player[i].color);
			score[i].setBounds(630 + pscore[i].getPreferredSize().width, 20 + (i * 30),
					pscore[i].getPreferredSize().width, score[i].getPreferredSize().height);
			add(score[i]);

		}
	}

	void score() {
		for (int i = 0; i < playernumber; i++) {
			if ((player[i].alive)) {
				player[i].score++;

			}
			score[i].setText("" + player[i].score);
		}
	}

	void gameOver() {
		for (int i = 0; i < playernumber; i++)
			if (player[i].alive)
				if (player[i].score >= 5 * (playernumber - 1))
					if (checkingScore(player[i]))
						timer.stop();
	}

	boolean checkingScore(Snake S) {
		for (int i = 0; i < playernumber; i++)
			if (S.score == player[i].score + 1)
				return false;
		return true;
	}

	void print() {
		for (int i = 0; i < playernumber; i++)
			System.out.println(i + ":" + " " + player[i].score);
	}

	int numberOfAliveplayer() {
		int num = 0;
		for (int i = 0; i < playernumber; i++)
			if (player[i].alive)
				num++;
		return num;
	}

	public void keyPressed(KeyEvent e) {
		for (int i = 0; i < playernumber; i++) {
			if (e.getKeyCode() == player[i].right) {
				player[i].key = 1;
				// player[i].rotate();
				System.out.println("right");
			} else if (e.getKeyCode() == player[i].left) {
				player[i].key = -1;
				// player[i].rotate();
			}
		}
		if (e.getKeyCode() == 32) {
			System.err.println("I AM HERE!!!");
			timer.start();
			timer.setRepeats(pause);
			pause = !pause;
		}

	}

	public void keyReleased(KeyEvent e) {

		for (int i = 0; i < playernumber; i++) {
			if (e.getKeyCode() == player[i].right) {
				player[i].key = 0;
				// player[i].rotate();
				System.out.println("right");
			} else if (e.getKeyCode() == player[i].left) {
				player[i].key = 0;
				// player[i].rotate();
			}
		}
	}

	public void keyTyped(KeyEvent e) {
	}
	/*
	 * public static void main(String[] args) { JFrame frame = new JFrame();
	 * frame.setVisible(true); frame.setSize(800,800);
	 * frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); Snake [] player =
	 * new Snake[3]; for(int i = 0;i<3;i++) player[i] = new Snake(); String d =
	 * "o"; String f = "p"; player[0].left = d.charAt(0); player[0].right =
	 * f.charAt(0);
	 * 
	 * Gameboard game = new Gameboard(player,3); frame.add(game); }
	 */
}
