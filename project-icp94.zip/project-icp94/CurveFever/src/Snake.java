// Asma Faraji Dizaji 610394120
import java.awt.Color;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.Random;

public class Snake {
	double firstx;
	double firsty;
	double[] lastx;
	double[] lasty;
	double x;
	double y;
	Color color;
	Color headcolor;
	Vector v;
	Vector[] vec;
	int[] path;
	boolean alive;
	boolean lost = false;
	boolean bot;
	int left;
	int right;
	int score;
	int l; 
	int key;
	double angle;
	Snake() {
		firstx = utils.rand.nextInt(300) + 100;
		firsty = utils.rand.nextInt(300) + 100;
		x = firstx;
		y = firsty;
		lastx = new double[20];
		lasty = new double[20];
		headcolor = new Color(utils.rand.nextInt(255), utils.rand.nextInt(255), utils.rand.nextInt(255));
		angle = utils.rand.nextDouble() * 2 * Math.PI;
		v = new Vector(1, angle);
		vec = new Vector[6];
		path = new int[6];
		alive = true;
		for(int i = 0;i<6;i++)
			vec[i] = new Vector(1,angle);
	}
	public void coloring(double[] lastx, double lasty[]) {
		for (int k = 0; k < 20; k++) {
			for (int i = (int) lastx[k]; i > 0 && i <= (lastx[k] + 7) && (i < 600); i++)
				for (int j = (int) lasty[k]; j > 0 && (j <= lasty[k] + 7) && (j < 700); j++)
					utils.colored[i][j] = -l;
		}
	}
	public boolean isAlive(double lastx[], double lasty[], int x, int y) {
		boolean alive = true;
		boolean crashborder = true;
		for (int i = x; (i <= x + 7) && (i < 600) && (i >= 0); i++)
			for (int j = y; (j <= y + 7) && (j < 700) && (j >= 0); j++) {
				if (utils.colored[i][j] != 0 && utils.colored[i][j] != -l) {
					alive = false; 
					i = x + 7;
					break;
				}
			}
		
		for (int i = (int) lastx[0]; (i <= lastx[0] + 7) && (i < 600) && (i >= 0); i++)
			for (int j = (int) lasty[0]; (j <= lasty[0] + 7) && (j < 700) && (j >= 0); j++) {
				utils.colored[i][j] = 1;
			}
		for (int i = x; i <= x + 7; i++)
			for (int j = y; j <= y + 7; j++)
				if (i == 2 || i == 600 - 2 || j == 2 || j == 700 - 2) {
					crashborder = false;
				}
		return (alive & crashborder);
	}
	void shift(double[] lastx, double[] lasty, double x, double y) {
		for (int i = 0; i < lastx.length - 1; i++) {
			lastx[i] = lastx[i + 1];
			lasty[i] = lasty[i + 1];

		}
		lastx[lastx.length - 1] = x;
		lasty[lasty.length - 1] = y;
	}

	boolean isBot() {
		return bot;
	}

	void rotate() {
		if (key != 0)
			v.ang += key * 3.0 / 60;
	}

	int getScore() {
		return score;
	}

	void imhaSpeedPowerUp() {
		if(v.len == 2.5)
			v.len = 1;
	}
	void checkpath()
	{
		int path = 0;
		double x = this.x;
		double y = this.y;
		for(int i = 0;i<50;i++)
		{
			x += this.v.getX();
			y += this.v.getY();
			for(int j = (int)x;j<(int)x + 7 && (j < 600) &&(j >= 0);j++)
				for(int k = (int)y;k<(int)y + 7 && (k < 700) &&(k >= 0);k++)
					if ((utils.colored[j][k] != 0 && utils.colored[j][k] != -l) || (590 <j&& j<600) || (690 < k && k < 700) || (0 < j && j < 10) || (k < 10 && k > 0)){
						path++; 
						break;
					}
		}
			if(path >= 1)
				adjustVector();
	}
	void adjustVector(){
			vec[0].ang = this.v.ang + 10.0/60;
			vec[0].len = this.v.len;
			vec[1].ang = this.v.ang +  10.0/60 * 2;
			vec[1].len = this.v.len;
			vec[2].ang = this.v.ang  + 10.0/60 * 3;
			vec[2].len = this.v.len;
			vec[3].ang = this.v.ang - 10.0/60;
			vec[3].len = this.v.len;
			vec[4].ang = this.v.ang - 10.0/60 * 2;
			vec[4].len = this.v.len; 
			vec[5].ang = this.v.ang - 10.0/60 * 3;
			vec[5].len = this.v.len;
	}
	void directionDignosing()
	{
		int max = -1;
		int index = 0;
		for(int i = 0;i<6;i++){
			path[i] = 0;
			path[i] = pathColor(vec[i]);
		}	
		for(int i = 0;i<6;i++)
			if(path[i] > max){
				max = path[i];
				index = i;
			}
		this.v = vec[index];			
	}
	int pathColor(Vector v)
	{
		double x = this.x;
		double y = this.y;
		int path = 0;
		
		for(int i = 0;i<50;i++)
		{
			x += v.getX();
			y += v.getY();
			for(int j = (int)x;j<(int)x + 7 && (j < 600) &&(j >= 0);j++)
				for(int k = (int)y;k<(int)y + 7 && (k < 700) &&(k >= 0);k++)
					if ((utils.colored[j][k] == 0 || utils.colored[j][k] == -l) && !(590 <j && j < 600) && !(690 < k && k < 800) && !(j > 0 && j < 20) && !(k > 0 && k < 20)){
						path++;
					}
					else
					{
						j = (int) x + 7;
						i = 100;
						break;
					}
		}
		return path;
	}
}
