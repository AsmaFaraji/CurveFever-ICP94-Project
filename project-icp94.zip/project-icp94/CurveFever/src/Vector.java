// Asma Faraji Dizaji 610394120
public class Vector {
	double len;
	double ang;

	// int x;
	// int y;
	Vector(double len, double ang) {
		this.len = len;
		this.ang = ang;
	}

	double getX() {
		return  (len * Math.cos(ang));
	}

	double getY() {
		return  (len * Math.sin(ang));
	}
} 
