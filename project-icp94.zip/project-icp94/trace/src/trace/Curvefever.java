package trace;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.Timer;

public class Curvefever {
	static int[][] colored = new int[1366][768];

	public static void main(String[] args) {
		JFrame f = new JFrame("SNAKE");
		f.setSize(1366, 768);
		f.setLocation(0, 0);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		Snake[] S = new Snake[1];
			S[0] = new Snake();
		//Move m = new Move(S);
		 Menu m = new Menu();
		 f.add(m);
	}
}
class Move extends JComponent implements ActionListener, KeyListener {
	Color color;
	ArrayList<Snake> Player;
	Timer timer;
	Graphics2D g2d;
	
	

	BufferedImage buffer;

	Move(ArrayList<Snake> player) {
		// System.out.println("f");
		this.Player = Player;

		this.setLocation(0, 0);
		this.setSize(1366, 768);
		this.setVisible(true);
		setFocusable(true);
		addKeyListener(this);

		buffer = new BufferedImage(1366, 768, BufferedImage.TYPE_INT_RGB);
		g2d = (Graphics2D) buffer.createGraphics();
		RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHints(rh);

		timer = new Timer(10, this);
		timer.start();

	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		for(Snake S : Player){
			if(S.alive){
				if(S.p == S.firstp){
					
				}
			}	
		}
		
	}

	public void keyPressed(KeyEvent e) {
		System.out.println("keypressed");
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
	
		}				
				
				
		 else if (e.getKeyCode() == KeyEvent.VK_LEFT)
			System.out.println("left is working");
//			for(int i = 0;i<3;i++)
		
		}
			
				
						
	

	public void keyReleased(KeyEvent e) {
	
	}

	public void keyTyped(KeyEvent e) {
	}

	public void actionPerformed(ActionEvent e) {
		//System.out.println("helo");
		repaint();
	}

	/*
	 * public void info(int x, int y, Color color) { this.x = x; this.y = y;
	 * this.color = color; }
	 */

}

class Vector {
	double len;
	double ang;

	// int x;
	// int y;
	Vector(double len, double ang) {
		this.len = len;
		this.ang = ang;
	}

	double getX() {
		return  (len * Math.sin(ang));
	}

	double getY() {
		return  (len * Math.cos(ang));
	}
}

class Point {
	double x;
	double y;

	Point(double x, double y) {
		this.x = x;
		this.y = y;
	}

	double getX() {
		return x;
	}

	double getY() {
		return y;
	}

	void setX(double x) {
		this.x = x;
	}

	void setY(double y) {
		this.y = y;
	}
	  void transfer(Vector v){ 
		  x += v.getX(); y += v.getY(); 
	  }
}