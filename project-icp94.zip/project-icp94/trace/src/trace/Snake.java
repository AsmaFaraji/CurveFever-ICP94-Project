package trace;

import java.awt.Color;
import java.util.Random;

class Snake {
	Random r;
	Point firstp;
	Point lastp;
	Point p;
	Color color;
	boolean alive = true;
	char left;
	char right;
	Vector v;
	Snake() {
		r = new Random();
		firstp = new Point(r.nextDouble()*800,r.nextDouble()*800);
		lastp = firstp;
		p = firstp;
		v = new Vector(0.5, 1);
		color = new Color(r.nextInt(255), r.nextInt(255), r.nextInt(255));
	}

	public void coloring(int x, int y) {
		for (int i = x; i < x + 4; i++)
			for (int j = y; j < y + 4; j++) {
				Curvefever.colored[i][j] = -1;
				// System.out.println("coloring:" + " " + "i:" + i + " " + "j:"
				// + j);
			}
	}

	public boolean isAlive(int lastx, int lasty, int x, int y) {
		boolean alive = true;
		boolean crashborder = true;
		for (int i = x; i < x + 4; i++)
			for (int j = y; j < y + 4; j++) {
				// System.out.println("alive1:" + " " + "i:" + i + " " + "j:" +
				// j);
				if (Curvefever.colored[i][j] != 0 && Curvefever.colored[i][j] != -1) {
					alive = false; // dead
					i = x + 4;
					break;
				}
			}
		for (int i = lastx; i < lastx + 4; i++)
			for (int j = lasty; j < lasty + 4; j++) {
				Curvefever.colored[i][j] = 1;
				// System.out.println("alive2:" + " " + "i:" + i + " " + "j:" +
				// j);
			}
		for (int i = x; i < x + 4; i++)
			for (int j = y; j < y + 4; j++)
				if (i == 2 || i == 800 - 2 || j == 2 || j == 800 - 2) {
					System.out.println("x:" + x + "y:" + y);
					crashborder = true;
				}
		return (alive & crashborder);
	}
}
