package trace;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.Border;

class Menu extends JPanel implements  MouseListener
{
	JLabel title1; JPanel t1;JPanel t12;
	JLabel title2; JPanel t2;
	ArrayList<JLabel> num; JPanel number;
	JTextField [] left;JPanel l;
	JTextField [] right;JPanel r;
	JLabel [] topic;
	JPanel player;
	JLabel bt;JPanel B;
	JButton [] bot;
	JButton start;JPanel strt;
	JPanel buttons;
	Component area;
	ArrayList<Snake> plyr;
	int botnumber;
	Menu()
	
	{
			//super(x);
			setSize(1366,768);
			setVisible(true);
			setLocation(0, 0);
			this.setForeground(Color.BLACK);
			this.setBackground(Color.BLACK);
			plyr = new ArrayList();
			title1 = new JLabel("C U R V E");
			title2 = new JLabel("F E V E R");
			title1.setFont(new Font("Liberation Serif", Font.BOLD,60));	
			title2.setFont(new Font("Liberation Serif", Font.ITALIC,60));
			title1.setForeground(Color.RED);
			title2.setForeground(Color.RED);
			t1 = new JPanel();
			t2 = new JPanel();
			t12 = new JPanel();
			t1.setBackground(Color.BLACK);
			t2.setBackground(Color.BLACK);
			
			topic = new JLabel[3];
			topic [0] = new JLabel("PLAYERS");
			topic[1] = new JLabel("LEFT" + " ");
			topic[2] = new JLabel("RIGHT");
			topic[0].setFont(new Font("Garandom", Font.LAYOUT_LEFT_TO_RIGHT,40));
			topic[0].setForeground(Color.YELLOW);
			topic[1].setFont(new Font("Garandom", Font.LAYOUT_LEFT_TO_RIGHT,50));
			topic[1].setForeground(Color.YELLOW);
			topic[2].setFont(new Font("Garandom", Font.LAYOUT_LEFT_TO_RIGHT,50));
			topic[2].setForeground(Color.YELLOW);
			
			num = new ArrayList(6);
			number = new JPanel();
			number.setBackground(Color.BLACK);
			number.setLayout(new BoxLayout(number, BoxLayout.Y_AXIS));
			
			left = new JTextField[6];
			l = new JPanel();
			l.setLayout(new BoxLayout(l, BoxLayout.Y_AXIS));
			l.setBackground(Color.BLACK);
			
			right = new JTextField[6];
			r = new JPanel();
			r.setLayout(new BoxLayout(r, BoxLayout.Y_AXIS));
			r.setBackground(Color.BLACK);
			
			bt = new JLabel("B O T S");
			bt.setFont(new Font("Garamond",Font.LAYOUT_NO_START_CONTEXT,30));
			bot = new JButton[6];
			B = new JPanel();
			B.setBackground(Color.BLACK);
			B.setLayout(new FlowLayout(FlowLayout.LEFT));
			
			t1.add(title1);
			t2.add(title2);
			t12.setLayout(new BoxLayout(t12,BoxLayout.Y_AXIS));
			t12.add(t1);
			t12.add(t2);
			
			number.add(topic[0]);
			Font f = new Font("Garadom",Font.CENTER_BASELINE,20);
			number.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));	
			for(int i = 0;i<6;i++){
				num.add(i, new JLabel((i + 1) + ""  + '.' + "PLAYER"));
				num.get(i).setFont(f);
				num.get(i).setForeground(Color.BLUE);
				number.add(num.get(i));
				num.get(i).setBorder(BorderFactory.createEmptyBorder(30, 10, 10, 10));	
			}
			l.add(topic [1]);
			for(int i = 0;i<6;i++){
				left[i] = new JTextField(1);
				left[i].setFont(new Font("Garandom",Font.BOLD,50));
				left[i].setForeground(Color.MAGENTA);
				left[i].setEditable(false);
				left[i].setBackground(Color.BLACK);
				l.add(left[i]);				
			}
			r.add(topic[2]);
			for(int i = 0;i<6;i++){
				right[i] = new JTextField(1);
				right[i].setFont(new Font("Garandom",Font.BOLD,50));
				right[i].setEditable(false);
				right[i].setForeground(Color.MAGENTA);
				right[i].setBackground(Color.BLACK);
				r.add(right[i]);
			}
			B.add(bt);
			for(int i = 0;i<6;i++){
				bot[i] = new JButton(i + 1 + "");
				bot[i].setBackground(Color.GREEN);
				bot[i].setForeground(Color.MAGENTA);			
				bot[i].setPreferredSize(new Dimension(50,50));
				bot[i].setFont(new Font("Garamond",Font.TRUETYPE_FONT,20));
				B.add(bot[i]);
			}
			strt = new JPanel();
			strt.setBackground(Color.BLACK);
			start = new JButton("P L A Y");
			start.setFont(new Font("Georgia",Font.BOLD,40));
			//play.setPreferredSize(new Dimension(100,100));
			start.setForeground(Color.PINK);
			start.setBackground(Color.BLACK);
			strt.add(start,BorderLayout.CENTER);
			
			area = Box.createRigidArea(new Dimension(1000,0));
			//area.setBackground(Color.BLACK);
			player = new JPanel();
			player.setBackground(Color.BLACK);
			player.setLayout(new BoxLayout(player, BoxLayout.X_AXIS));
			player.add(number);
			player.add(l);
			player.add(r);
			player.add(area);
		
			
	
			buttons = new JPanel();
			buttons.setLayout(new BoxLayout(buttons,BoxLayout.Y_AXIS));
			buttons.add(B);
			buttons.add(strt);
			setLayout(new BorderLayout());
			add(t12,BorderLayout.NORTH);
			add(player,BorderLayout.CENTER);
			add(buttons,BorderLayout.SOUTH);
			
			
			for(int i = 0;i<6;i++){
				num.get(i).addMouseListener(this);
			}
			for(int i = 0;i<6;i++)
				bot[i].setActionCommand(i + 1 + "");
			start.setActionCommand("Play");
		}
	public void mouseClicked(MouseEvent event) {}
	public void mouseEntered(MouseEvent event) {}
	public void mouseExited(MouseEvent event) {}
	public void mousePressed(MouseEvent event) {
		JLabel label = (JLabel)event.getSource();
		for(int i = 0;i<6;i++){
			if(num.get(i) == label)
				left[i].setEditable(true);
				right[i].setEditable(true);
				plyr.add(i,new Snake());
				plyr.get(i).left = left[i].getText().charAt(0);
				plyr.get(i).right = right[i].getText().charAt(0);
		}
	}
	public void mouseReleased(MouseEvent e) {}
	/*public void actionPerformed(ActionEvent e){
		for(int i = 0;i<6;i++)
			if(e.getActionCommand().equals(i + 1 + ""))
				botnumber = i + 1;
		//if(e.getActionCommand().equals("play"))
			
	}*/
}