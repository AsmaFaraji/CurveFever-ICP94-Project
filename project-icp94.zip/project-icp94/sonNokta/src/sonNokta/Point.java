public class Point {
	double x;
	double y;

	Point(double x, double y) {
		this.x = x;
		this.y = y;
	}

	double getX() {
		return x;
	}

	double getY() {
		return y;
	}

	void setX(double x) {
		this.x = x;
	}

	void setY(double y) {
		this.y = y;
	}
	void transfer(Vector v){ 
		  this.x += v.getX(); 
		  this.y += v.getY(); 
	  }
	boolean Compare(Point p)
	{
		  if(this.x == p.x && this.y == p.y)
			  return true;
		  return false;
	 }
	public String  toString()
	{
		return "x = " + x + " " + "y = " + y;
	}
}