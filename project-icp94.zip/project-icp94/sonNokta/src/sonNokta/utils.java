import java.util.Random;

public final class utils {
	public static Random rand = new Random();
	static int [][] colored = new int[600][700] ;
}
