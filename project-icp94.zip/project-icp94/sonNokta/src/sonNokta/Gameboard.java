import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.swing.Timer;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Gameboard extends JComponent implements KeyListener, ActionListener {

	Snake[] player;
	JLabel[] pscore;
	JLabel[] score;
	PowerUp[] sposition;
	int playernumber;
	Graphics2D g2d;
	Graphics2D g;
	BufferedImage buffer;
	BufferedImage img;
	Timer timer;
	Timer time;
	ActionListener power;
	boolean powerappear;
	boolean pause = true;
	boolean a = false;
	int x = 0;
	int y = 0;
	int counter;
	int alives;
	Snake snake[];
	JFrame frame;
	JFrame jf;

	public Gameboard(Snake[] player, int playernumber, JFrame frame) {
		this.setBounds(0, 0, 800, 700);
		this.setVisible(true);
		setFocusable(true);
		addKeyListener(this);
		this.player = player;
		this.playernumber = playernumber;
		alives = playernumber;
		this.frame = frame;
		pscore = new JLabel[playernumber];
		score = new JLabel[playernumber];
		buffer = new BufferedImage(800, 700, BufferedImage.TYPE_INT_RGB);
		g2d = (Graphics2D) buffer.getGraphics();
		snake = new Snake[playernumber];
		for(int i = 0;i<playernumber;i++)
			snake[i] = player[i];

		RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		rh.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHints(rh);

		scoreBoard();
		drawFirstDirection();
		timer = new Timer(14, this);
	}

	public void actionPerformed(ActionEvent e) {
		//System.out.println("done");
		for (int i = 0; i < playernumber; i++) {
			if (!player[i].isBot()){
				Movement(player[i]);
			//	repaint();
			}	
			 else{
				 player[i].checkpath();
				 player[i].directionDignosing();
				 Movement(player[i]);
			 }
		}
		repaint();

	}

	public void paintComponent(Graphics g) {
		this.g = (Graphics2D)g;
		int tedad;
		int identifier;
		counter++;
		g.drawImage(buffer, 0, 0, null);
		for(int i = 0;i<playernumber;i++){
			this.g.setColor(snake[i].headcolor);
			this.g.fill(new Ellipse2D.Double(snake[i].x, snake[i].y, 7, 7));
		}

		if (!a && counter % 200 == 0) {
			if (utils.rand.nextDouble() < 0.5) {
				a = true;
				x = utils.rand.nextInt(500) + 100;
				y = utils.rand.nextInt(500) + 100;
				Timer t = new Timer(10, new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						a = false;
						for(int i = 0;i<playernumber;i++)
							player[i].imhaSpeedPowerUp();
					}
				});
				t.setRepeats(false);
				t.setInitialDelay(10000);
				t.start();
				tedad = 2;
				sposition = new PowerUp[tedad];
				sposition[0] = new PowerUp(0);
				sposition[1] = new PowerUp(1);
			}
		}

		if (a) {
			for (int i = 0; i < sposition.length; i++) {
				
				if (sposition[i].identifier == 1 &&  sposition[i].catched == false) {
					try {
						img = ImageIO.read(this.getClass().getResource("1.png"));// qermez soraat baqiye ziad mishe
						g.drawImage(img, sposition[i].x, sposition[i].y, null);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}	
			 
				  	if(sposition[i].identifier == 0 &&  sposition[i].catched == false){
					try {
						img = ImageIO.read(this.getClass().getResource("2.png"));
						g.drawImage(img, sposition[i].x, sposition[i].y, null);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				sposition[i].speedPowerUp(player, playernumber);
			}
		}

	}

	protected void paintBorder(Graphics g) {
		g.setColor(Color.blue);
		g.drawRect(0, 0, 600, 698);
		g.drawRect(601, 0, 198, 698);
	}
	void drawFirstDirection() {
		for (int i = 0; i < playernumber; i++) {
			for (int j = 0; j < 19; j++) {
				Color c = new Color(buffer.getRGB(0, 0));
				g2d.setColor(player[i].color);
				g2d.fill(new Ellipse2D.Double(player[i].x, player[i].y, 7, 7));
				player[i].lastx[j] = player[i].x;
				player[i].lasty[j] = player[i].y;
				player[i].x += player[i].v.getX();
				player[i].y += player[i].v.getY();
			}
			player[i].lastx[19] = player[i].x;
			player[i].lasty[19] = player[i].y;
			player[i].coloring(player[i].lastx, player[i].lasty);
			repaint();
		}
	}

	void Movement(Snake S) {
		if (S.alive) {
			g2d.setColor(S.color);
			g2d.fill(new Ellipse2D.Double(S.x, S.y, 7, 7));
			S.rotate();
			S.x += S.v.getX();
			S.y += S.v.getY();
			S.alive = S.isAlive(S.lastx, S.lasty, (int) S.x, (int) S.y);
			S.shift(S.lastx, S.lasty, S.x, S.y);
			S.coloring(S.lastx, S.lasty);
			if (!S.alive && !S.lost) {
				S.lost = true;
				score();
				numberOfAlivePlayer();
			}
		}
	}

	void appearPowerUp() {
		int tedad;
		int identifier;
		if (utils.rand.nextDouble() < 0.03) {
			tedad = utils.rand.nextInt(5) + 1;
			sposition = new PowerUp[tedad];
			for (int i = 0; i < tedad; i++) {
				System.out.println("powerup");
				identifier = utils.rand.nextInt(2);
				sposition[i] = new PowerUp(identifier);
				try {
					img = ImageIO.read(this.getClass().getResource("p.png"));
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}
	}

	public void scoreBoard() {
		for (int i = 0; i < playernumber; i++) {
			pscore[i] = new JLabel("" + (i + 1) + '.' + "PLAYER");
			pscore[i].setFont(new Font("Garandom", Font.BOLD, 10));
			pscore[i].setForeground(player[i].color);
			pscore[i].setBounds(610, 20 + (i * 30), pscore[i].getPreferredSize().width,
					pscore[i].getPreferredSize().height);
			add(pscore[i]);
			score[i] = new JLabel("" + player[i].score);
			score[i].setFont(new Font("Garandom", Font.BOLD, 10));
			score[i].setForeground(player[i].color);
			score[i].setBounds(630 + pscore[i].getPreferredSize().width, 20 + (i * 30),
					pscore[i].getPreferredSize().width, score[i].getPreferredSize().height);
			add(score[i]);

		}
	}

	void score() {
		for (int i = 0; i < playernumber; i++) {
			if ((player[i].alive)) {
				player[i].score++;

			}
			score[i].setText("" + player[i].score);
		}
	}

	boolean gameOver() {
		for (int i = 0; i < playernumber; i++)
			if (player[i].alive)
				if (player[i].score >= 5 * (playernumber - 1))
					if (checkingScore(player[i]))
						return true;
		return false;
	}

	boolean checkingScore(Snake S) { // halate naghis dar nazar begir
		for (int i = 0; i < playernumber; i++)
				if(player[i] != S )
					if (Math.abs(S.score - player[i].score) <= 1 )
						return false;
		return true;
	}

	void numberOfAlivePlayer() {
		boolean over = false;
		int win  = 0;
		int score = 0;
		alives--;
		if(alives == 1){
		 over = gameOver();
			if(!over){
				for(int i = 0;i<600;i++)
					for(int j = 0;j<700;j++)
						utils.colored[i][j] = 0;
				for(int i = 0;i<playernumber;i++){
					player[i].alive = true;
					player[i].lost = false;
					player[i].v.len = 1;
					player[i].key = 0;
					player[i].x = utils.rand.nextInt(300) + 100;
					player[i].y = utils.rand.nextInt(300) + 100;
				}
				frame.dispose();
				JFrame f = new JFrame();
				f.setSize(800,700);
				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f.setVisible(true);
				Gameboard game = new Gameboard(player, playernumber,f);
				f.add(game);
				timer.stop();
			}
			else
			{
				for(int i = 0;i<playernumber;i++)
					if(player[i].score > score){
						win = i;
						score = player[i].score;
					}
				timer.stop();
				 jf = new JFrame();
				jf.setLayout(null);
				jf.getContentPane().setBackground(Color.GREEN);
				jf.getContentPane().setForeground(Color.GREEN);
				jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				jf.setBounds(200 , 150, 400 , 400);
				jf.setVisible(true);
				JLabel name  = new JLabel(win + 1 + "." + "PLAYER    WINS");
				JLabel congratulation  = new JLabel("CONGRATULATION");
				name.setFont(new Font("Garandom",Font.ITALIC, 30));
				name.setBounds(50, 50,name.getPreferredSize().width, name.getPreferredSize().height);
				name.setForeground(player[win].color);
				congratulation.setFont(new Font("Garandom",Font.ITALIC, 30));
				congratulation.setBounds(50,  100, congratulation.getPreferredSize().width,  congratulation.getPreferredSize().height);
				congratulation.setForeground(Color.BLUE);
				jf.add(name);
				jf.add(congratulation);
				JButton button = new JButton("OK");
				button.setBackground(Color.BLUE);
				button.setFont(new Font("Garandom", Font.ITALIC, 20));
				button.setBounds(200,250,button.getPreferredSize().width, button.getPreferredSize().height);
				jf.add(button);
				finish(button);
			}
		}
	}
	void finish(JButton button){
		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				frame.dispose();
				jf.dispose();
				//frame.dispose();
				Menu m = new Menu();
			}
		});
	}

	public void keyPressed(KeyEvent e) {
		for (int i = 0; i < playernumber; i++) {
			if (e.getKeyCode() == player[i].right) {
				player[i].key = 1;
			} else if (e.getKeyCode() == player[i].left) {
				player[i].key = -1;
			}
		}
		if (e.getKeyCode() == 32) {
			timer.start();
			timer.setRepeats(pause);
			pause = !pause;
		}
		if(e.getKeyCode() == 27){
			timer.stop();
			frame.dispose();
			Menu menu = new Menu();
		}

	}

	public void keyReleased(KeyEvent e) {

		for (int i = 0; i < playernumber; i++) {
			if (e.getKeyCode() == player[i].right) {
				player[i].key = 0;
			} else if (e.getKeyCode() == player[i].left) {
				player[i].key = 0;
			}
		}
	}

	public void keyTyped(KeyEvent e) {
	}

}
